/* eslint-disable no-promise-executor-return */
/* eslint-disable no-undef */
Feature('Likeing Resto');

Scenario('Add and Delete Resto', async ({ I }) => {
  I.amOnPage('/');
  await new Promise((resolve) => setTimeout(resolve, 5000));
  I.click('.hero__tagline');
  await new Promise((resolve) => setTimeout(resolve, 4000));
  I.seeElement('.list_item_title');
  const restaurantTitl = locate('.list_item_title').first();
  I.click(restaurantTitl);
  await new Promise((resolve) => setTimeout(resolve, 4000));
  I.seeElement('#likeButton');
  I.click('#likeButton');
  await new Promise((resolve) => setTimeout(resolve, 5000));
  I.amOnPage('/#/favorite');
  await new Promise((resolve) => setTimeout(resolve, 4000));
  I.seeElement('.list_item_title');
  const restaurantTitle = locate('.list_item_title').first();
  I.click(restaurantTitle);
  await new Promise((resolve) => setTimeout(resolve, 4000));
  I.seeElement('#likeButton');
  I.click('#likeButton');
  await new Promise((resolve) => setTimeout(resolve, 5000));
});
