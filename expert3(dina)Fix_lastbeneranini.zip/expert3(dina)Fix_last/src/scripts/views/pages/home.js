import YummyRestoSource from '../../data/restokudb-source';
import { createRestoItemTemplate } from '../templates/template-creator';

const Home = {
  async render() {
    return `
    <div class="list" id="tes"></div>
    `;
  },

  async afterRender() {
    const restos = await YummyRestoSource.getRestaurantList();
    const restoContainer = document.querySelector('.list');
    restos.forEach((resto) => {
      restoContainer.innerHTML += createRestoItemTemplate(resto);
    });
  },
};

export default Home;
