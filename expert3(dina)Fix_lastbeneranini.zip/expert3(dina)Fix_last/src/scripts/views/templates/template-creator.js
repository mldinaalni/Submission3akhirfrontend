import CONFIG from '../../globals/config';

const createRestoDetailTemplate = (resto) => `
  <div class="list_item">
              <img class="list_item_thumb" src="${resto.pictureId ? CONFIG.BASE_IMAGE_URL_MEDIUM + resto.pictureId : 'https://picsum.photos/id/666/800/450?grayscale'}" alt="${resto.name}" title="${resto.name}">
              <div class="city">${resto.city}</div>
              <div class="list_item_content">
                  <p class="list_item_rating">
                      Rating : 
                      <p class="list_item_rating_value">${resto.rating}</p>
                  </p>
                  <p class="list_item_rating">
                      Alamat : 
                      <p class="list_item_rating_value">${resto.address}</p>
                  </p>
                  <h1 class="list_item_title"><p>${resto.name}</p></h1>
                  <div class="list_item_desc">${resto.description.slice(0, 150)}...</div>
              </div>
          </div>
           <div class="list_item">
              <div class="list_item_content">
                  <h1 class="list_item_title"><p>Makanan & Minuman</p></h1>
                  <h2>Makanan</h2>
                  <div class="list_item_desc menus">${resto.menus.foods.map((food) => `<li class="food-item">${food.name}</li>`).join('')}</div>
                  <h2>Minuman</h2>
                  <div class="list_item_desc menus" >${resto.menus.drinks.map((drink) => `<li class="drink-item">${drink.name}</li>`).join('')}</div>
              </div>
          </div>
          <div class="list_item">
              <div class="list_item_content">
                  <h1 class="list_item_title"><p>Review</p></h1>
    <div tabindex="0" class="detail-review">
      ${resto.customerReviews
    .map(
      (review) => `
      <div class="detail-review-item">
        <div class="header-review">
          <p class="name-review"><i title="restaurant" class="fa fa-user-circle" style="font-size:1.3em; padding-right:10px;"></i>${review.name}</p>
          <p class="date-review">${review.date}</p>
        </div>
        <div class="body-review">
          ${review.review}
        </div>
      </div>
      `,
    )
    .join('')}
    </div>
              </div>
          </div>
          
`;

const createRestoItemTemplate = (resto) => `
   <div class="list_item">
              <img class="list_item_thumb lazyload" data-src="${resto.pictureId ? CONFIG.BASE_IMAGE_URL_MEDIUM + resto.pictureId : 'https://picsum.photos/id/666/800/450?grayscale'}" alt="${resto.name}" title="${resto.name}">
              <div class="city">${resto.city}</div>
              <div class="list_item_content">
                  <p class="list_item_rating">
                      Rating : 
                      <a href="" class="list_item_rating_value">${resto.rating}</a>
                  </p>
                  <h1 class="list_item_title"><a href="/#/resto/${resto.id}">${resto.name}</a></h1>
                  <div class="list_item_desc">${resto.description.slice(0, 150)}...</div>
              </div>
          </div>
`;

const createLikeButtonTemplate = () => `
  <button aria-label="like this resto" id="likeButton" class="like">
     <i class="fa fa-heart-o" aria-hidden="true"></i>
  </button>
`;

const createLikedButtonTemplate = () => `
  <button aria-label="unlike this resto" id="likeButton" class="like">
    <i class="fa fa-heart" aria-hidden="true"></i>
  </button>
`;

export {
  createRestoItemTemplate,
  createRestoDetailTemplate,
  createLikeButtonTemplate,
  createLikedButtonTemplate,
};
